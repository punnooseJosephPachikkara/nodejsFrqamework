const express = require('express');
const router = express.Router();
const Classes = require('../model/class');

// get a list of class from the database
router.get('/class',function(req,res,next){
    Classes.find({}).then(function(cla){
        res.send(cla);
    }).catch(next);
});

// add a new student to database
router.post('/class',function(req,res,next){
    Classes.create(req.body).then(function(cla){
        res.send(cla);
    }).catch(next);
});

// update a student in the database
router.put('/class/:id',function(req,res,next){
    Classes.findOneAndUpdate({_id: req.params.id},req.body).then(function(cla){
        Classes.findOne({_id: req.params.id}).then(function(cla){
            res.send(cla);
        });
    });
});

// delete a student in the database
router.delete('/class/:id',function(req,res,next){
    Classes.findOneAndDelete({_id: req.params.id}).then(function(cla){
        res.send(cla);
    });
});

module.exports = router;