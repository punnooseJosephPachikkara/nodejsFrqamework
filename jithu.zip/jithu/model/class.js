const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// create student schema & modelcd
const ClassSchema = new Schema({
    name: {
        type: String,
    },
    roll: {
        type: String,
        required: [true, 'Roll field is required']
    },
    present: {
        type: Boolean,
        deafult: true
    }
});


const cla = mongoose.model('class',ClassSchema);

module.exports = cla;